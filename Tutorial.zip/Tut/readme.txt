Program/Tutorial Built by Farzain M.

Ask me any questions/troll me on twitter @farzatv

Here I explain how to get the module "requests".  Its extremely easy and the only thing that makes it hard is changing your enviroment variables. I'll explain below. If you have an other errors just GOOGLE IT!

BEFORE YOU RUN THE PROGRAM

Before doing anything, we need to install a module called "requests".  It allows the program to grab data from Riots API.  Without it, the program WILL NOT WORK.

STEP ONE
Download Python Version 2.7.10: https://www.python.org/downloads/

STEP TWO
Awesome, now you have Python! Now go to your Command Prompt or Terminal. Once your in your Terminal, simply type in "python" and press enter. 
If you get this error: 'python' is not recognized as an internal or external command, operable program or batch file.
Then you need to change your enviroment variables. There is an awesome walkthrough on how to do that here: http://pythoncentral.io/add-python-to-path-python-is-not-recognized-as-an-internal-or-external-command/
After, type in "python" in command line to ensure you did this correctly. You should see stuff.  Close and reopen Command Prompt. 

STEP THREE
In your Terminal change your directory (using the "cd" command) to where my program and all its files are. For example, if the file is on your Desktop type in: cd C:\Users\(ENTER YOUR COMPUTERS NAME HERE)\Desktop\Tut 

STEP FOUR
We need to install pip. So once your in my programs directory, type in: python get-pip.py

STEP FIVE
Now go ahead in Terminal and type in: pip
If you get this error: 'pip' is not recognized as an internal or external command, operable program or batch file.
Then you need to change your enviroment variables. You can do this using the same method you used to add Python above. Except this time, once your in Enviroment Variables, click PATH, then Edit, and add your Python 
scripts path.  Mines is "C:\Python27\Scripts".  Type in "pip" in command line to ensure you did this correctly. You should see stuff. Close and reopen Command Prompt. 

STEP SIX
Finally, install requests. Simply type in "pip install requests"


Feel free to message me on Youtube or message me on Twitter @farzatv if you have questions.

PEACE OUT.

-Farzain M.